package com.example.zipapk

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

// Client ID de tu OAuth App de GitHub (con Device Flow activado)
const val CLIENT_ID = "Ov23lihmBdPjIbbvpSye"
const val REPO = "apk-builder"
private const val API = "https://api.github.com"

class GitHub(private val token: String?) {
    private val http = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    private fun call(method: String, url: String, body: JSONObject? = null): Pair<Int, JSONObject> {
        val b = Request.Builder().url(url).header("Accept", "application/vnd.github+json")
        if (token != null) b.header("Authorization", "Bearer $token")
        val rb = when {
            body != null -> body.toString().toRequestBody(jsonType)
            method == "GET" -> null
            else -> "".toRequestBody()
        }
        b.method(method, rb)
        http.newCall(b.build()).execute().use { r ->
            val t = r.body?.string().orEmpty()
            return r.code to (if (t.startsWith("{")) JSONObject(t) else JSONObject())
        }
    }

    private fun form(url: String, vararg p: Pair<String, String>): JSONObject {
        val fb = FormBody.Builder()
        p.forEach { fb.add(it.first, it.second) }
        val r = Request.Builder().url(url).header("Accept", "application/json").post(fb.build()).build()
        http.newCall(r).execute().use { return JSONObject(it.body!!.string()) }
    }

    // ---------- Login (Device Flow) ----------
    suspend fun deviceCode(): JSONObject = withContext(Dispatchers.IO) {
        form("https://github.com/login/device/code", "client_id" to CLIENT_ID, "scope" to "repo workflow")
    }

    suspend fun pollToken(deviceCode: String, interval: Int, expiresIn: Int): String =
        withContext(Dispatchers.IO) {
            var wait = interval
            var left = expiresIn
            while (left > 0) {
                delay(wait * 1000L)
                left -= wait
                val r = form(
                    "https://github.com/login/oauth/access_token",
                    "client_id" to CLIENT_ID,
                    "device_code" to deviceCode,
                    "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
                )
                if (r.has("access_token")) return@withContext r.getString("access_token")
                when (r.optString("error")) {
                    "authorization_pending" -> {}
                    "slow_down" -> wait += 5
                    else -> error(r.optString("error_description", "Error de inicio de sesión"))
                }
            }
            error("El código expiró, inténtalo de nuevo")
        }

    // ---------- Compilación ----------
    private fun putFile(owner: String, path: String, data: ByteArray, branch: String, message: String) {
        val url = "$API/repos/$owner/$REPO/contents/$path"
        val sha = call("GET", "$url?ref=$branch").second.optString("sha")
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(data, Base64.NO_WRAP))
            .put("branch", branch)
        if (sha.isNotEmpty()) body.put("sha", sha)
        val (code, resp) = call("PUT", url, body)
        require(code in 200..201) { resp.optString("message", "Error $code al subir $path") }
    }

    /** name: nombre del proyecto (se usa en el .yml, el ZIP y el artefacto). */
    suspend fun build(
        zip: ByteArray,
        name: String,
        workflowTemplate: String,
        cacheDir: File,
        status: (String) -> Unit
    ): File = withContext(Dispatchers.IO) {
        status("Preparando tu repositorio…")
        val owner = call("GET", "$API/user").second.getString("login")
        val created = call(
            "POST", "$API/user/repos",
            JSONObject().put("name", REPO).put("private", true).put("auto_init", true)
        ).first
        if (created == 201) delay(3000)
        val branch = call("GET", "$API/repos/$owner/$REPO").second.optString("default_branch", "main")

        // Un .yml por proyecto, generado desde la plantilla cambiando solo el nombre
        status("Creando el workflow de $name…")
        val yml = workflowTemplate.replace("__NAME__", name)
        putFile(owner, ".github/workflows/$name.yml", yml.toByteArray(), branch, "workflow $name")
        delay(2000)

        // Subir el ZIP a la raíz: el push dispara el workflow solo
        val id = System.currentTimeMillis().toString()
        status("Subiendo $name.zip…")
        putFile(owner, "$name.zip", zip, branch, "build $id")

        var conclusion = ""
        var runId = 0L
        var tries = 0
        while (conclusion.isEmpty() && tries++ < 240) {
            delay(5000)
            val runs = call(
                "GET", "$API/repos/$owner/$REPO/actions/runs?event=push&per_page=10"
            ).second.optJSONArray("workflow_runs") ?: continue
            for (i in 0 until runs.length()) {
                val r = runs.getJSONObject(i)
                if (r.optString("display_title").contains(id)) {
                    val st = r.getString("status")
                    status(if (st == "completed") "Finalizando…" else "Compilando en GitHub ($st)…")
                    if (st == "completed") {
                        conclusion = r.optString("conclusion", "failure")
                        runId = r.getLong("id")
                    }
                }
            }
        }
        if (conclusion != "success") {
            var failed = ""
            try {
                val jobs = call("GET", "$API/repos/$owner/$REPO/actions/runs/$runId/jobs")
                    .second.optJSONArray("jobs")
                if (jobs != null) for (j in 0 until jobs.length()) {
                    val steps = jobs.getJSONObject(j).optJSONArray("steps") ?: continue
                    for (k in 0 until steps.length()) {
                        val st = steps.getJSONObject(k)
                        if (failed.isEmpty() && st.optString("conclusion") == "failure") failed = st.optString("name")
                    }
                }
            } catch (_: Exception) {}
            error(
                if (conclusion.isEmpty()) "Tiempo de espera agotado (no se inició el workflow)"
                else "La compilación falló" + (if (failed.isNotEmpty()) " en el paso «$failed»" else "") +
                    ". Log completo: github.com/$owner/$REPO > Actions."
            )
        }

        status("Descargando el APK…")
        val arts = call("GET", "$API/repos/$owner/$REPO/actions/runs/$runId/artifacts")
            .second.optJSONArray("artifacts")
        require(arts != null && arts.length() > 0) { "No se encontró el artefacto del APK" }
        val artId = arts.getJSONObject(0).getLong("id")
        val out = File(cacheDir, "apks").apply { mkdirs() }.resolve("$name-$id.apk")
        val req = Request.Builder()
            .url("$API/repos/$owner/$REPO/actions/artifacts/$artId/zip")
            .header("Accept", "application/vnd.github+json")
            .header("Authorization", "Bearer $token")
            .build()
        http.newCall(req).execute().use { r ->
            require(r.isSuccessful) { "Descarga fallida (${r.code})" }
            ZipInputStream(r.body!!.byteStream()).use { zin ->
                var e = zin.nextEntry
                var found = false
                while (e != null && !found) {
                    if (e.name.endsWith(".apk")) {
                        out.outputStream().use { zin.copyTo(it) }
                        found = true
                    } else e = zin.nextEntry
                }
                require(found) { "El artefacto no contiene ningún APK" }
            }
        }
        out
    }
}
