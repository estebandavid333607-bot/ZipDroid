package com.example.zipapk

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

private fun securePrefs(c: Context) = EncryptedSharedPreferences.create(
    "secure", MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC), c,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)

private fun projectName(ctx: Context, uri: Uri): String {
    var n = "proyecto"
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) n = it.getString(0) ?: n
    }
    return n.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "-").ifEmpty { "proyecto" }
}

private fun install(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { securePrefs(ctx) }
    var token by remember { mutableStateOf(prefs.getString("token", null)) }
    var status by remember { mutableStateOf("") }
    var login by remember { mutableStateOf<Pair<String, String>?>(null) } // código, url
    var busy by remember { mutableStateOf(false) }
    var apk by remember { mutableStateOf<File?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        apk = null
        scope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                }
                val yml = withContext(Dispatchers.IO) {
                    ctx.assets.open("build.yml").bufferedReader().use { it.readText() }
                }
                apk = GitHub(token).build(bytes, projectName(ctx, uri), yml, ctx.cacheDir) { status = it }
                status = "¡Listo! Tu APK está generado."
            } catch (e: Exception) {
                status = "Error: ${e.message}"
            }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("ZipDroid", style = MaterialTheme.typography.headlineMedium)

        if (token == null) {
            Button(enabled = login == null, onClick = {
                scope.launch {
                    try {
                        val gh = GitHub(null)
                        val d = gh.deviceCode()
                        login = d.getString("user_code") to d.getString("verification_uri")
                        val t = gh.pollToken(d.getString("device_code"), d.getInt("interval"), d.getInt("expires_in"))
                        prefs.edit().putString("token", t).apply()
                        token = t
                    } catch (e: Exception) {
                        status = "Error: ${e.message}"
                    }
                    login = null
                }
            }) { Text("Iniciar sesión con GitHub") }

            login?.let { (code, url) ->
                Text("Abre $url e introduce este código:")
                Text(code, style = MaterialTheme.typography.headlineLarge)
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Abrir GitHub") }
                CircularProgressIndicator()
            }
        } else {
            Button(enabled = !busy, onClick = {
                picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }) { Text("Elegir ZIP del proyecto") }

            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            apk?.let { f -> Button(onClick = { install(ctx, f) }) { Text("Instalar APK") } }

            TextButton(enabled = !busy, onClick = {
                prefs.edit().remove("token").apply()
                token = null
                status = ""
                apk = null
            }) { Text("Cerrar sesión") }
        }

        if (status.isNotEmpty()) Text(status)
    }
}
